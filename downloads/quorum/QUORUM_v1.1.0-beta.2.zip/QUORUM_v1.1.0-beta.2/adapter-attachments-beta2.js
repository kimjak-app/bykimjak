(() => {
  const req = REQUEST_JSON;
  const answer = (ok, reason, extra={}) => ({ok, reason, ...extra});
  const visible = e => {
    if (!e || !e.isConnected || e.closest('[aria-hidden="true"], [inert]')) return false;
    const r=e.getBoundingClientRect(), s=getComputedStyle(e);
    return r.width>2 && r.height>2 && r.bottom>0 && r.right>0 && r.top<innerHeight && r.left<innerWidth && s.visibility!=='hidden' && s.display!=='none';
  };
  const all = selector => {
    const found=[];
    const visit=root=>{found.push(...root.querySelectorAll(selector));for(const e of root.querySelectorAll('*'))if(e.shadowRoot)visit(e.shadowRoot);};
    visit(document);return found;
  };
  const editable = e => e && (e.tagName==='TEXTAREA' || e.isContentEditable || (e.tagName==='INPUT' && e.getAttribute('role')==='textbox'));
  const host = location.hostname;
  const providers = {
    ChatGPT: {hosts:['chatgpt.com'], editors:['#prompt-textarea','textarea[data-id="root"]'], send:['button[data-testid="send-button"]']},
    Claude: {hosts:['claude.ai'], editors:['[contenteditable="true"].ProseMirror','[contenteditable="true"][role="textbox"]'], send:['button[aria-label="Send message"]']},
    Grok: {hosts:['grok.com'], editors:['textarea','[contenteditable="true"][role="textbox"]'], send:['button[aria-label="Submit"]','button[aria-label="Send message"]']},
    Gemini: {hosts:['gemini.google.com'], editors:['rich-textarea [contenteditable="true"]','[contenteditable="true"][role="textbox"]'], send:['button.send-button','button[aria-label="Send message"]']}
  };
  const p = providers[req.provider];
  if (!p || (!p.hosts.includes(host) && !(req.test && (location.href === 'about:blank' || location.href.startsWith('data:text/html')))))
    return answer(false,'지원하는 AI 채팅 페이지에서만 입력할 수 있습니다.');
  if(req.action==='pick') {
    if(window.__meetingPickAbort)window.__meetingPickAbort.abort();
    const abort=new AbortController();window.__meetingPickAbort=abort;
    document.addEventListener('click',event=>{
      let e=event.composedPath().find(editable);
      if(!e)return;
      while(e.parentElement && e.parentElement.isContentEditable)e=e.parentElement;
      window.__meetingEditor=e;abort.abort();
      const old=e.style.outline;e.style.outline='3px solid #17b890';setTimeout(()=>{e.style.outline=old;},1800);
    },{capture:true,signal:abort.signal});
    setTimeout(()=>abort.abort(),30000);
    return answer(true,'30초 안에 이 AI의 메시지 입력칸을 클릭하세요. 초록 테두리가 나타나면 지정 완료입니다.');
  }
  const buttonLabel=e=>(e.getAttribute('aria-label') || e.getAttribute('title') || e.textContent || '').trim();
  if (all('button').some(e => visible(e) && /^(stop|stop generating|stop response|응답 중지|생성 중지|중지)$/i.test(buttonLabel(e))))
    return answer(false,'AI가 응답 중입니다. 응답이 끝난 뒤 다시 시도하세요.');
  let editor=visible(window.__meetingEditor) && editable(window.__meetingEditor)?window.__meetingEditor:null;
  for (const selector of p.editors) {
    if(editor)break;
    const matches = all(selector).filter(visible).filter(editable);
    if (matches.length === 1) { editor=matches[0]; break; }
  }
  if(!editor){
    let matches=all('textarea,[contenteditable],[role="textbox"]').filter(visible).filter(editable).filter(e=>!e.disabled && !e.readOnly && e.getAttribute('aria-disabled')!=='true');
    matches=matches.filter(e=>!matches.some(parent=>parent!==e && parent.contains(e) && parent.isContentEditable));
    const score=e=>{
      const label=[e.id,e.getAttribute('aria-label'),e.getAttribute('placeholder'),e.getAttribute('data-placeholder')].join(' ');
      let n=/prompt|message|메시지|물어보|질문|프롬프트|무엇을|앱을 검색/i.test(label)?10:0;
      if(e.closest('rich-textarea,form,[data-testid*="composer"]'))n+=2;
      if(/search|검색/.test(label) && !/앱을 검색/.test(label))n-=20;
      return n;
    };
    matches.sort((a,b)=>score(b)-score(a));
    if(matches.length===1 && score(matches[0])>=0)editor=matches[0];
    else if(matches.length>1 && score(matches[0])>score(matches[1]) && score(matches[0])>0)editor=matches[0];
  }
  if (!editor || editor.disabled || editor.getAttribute('aria-disabled') === 'true')
    return answer(false,'입력칸을 식별하지 못했습니다. 위의 입력칸 지정 버튼을 누르고 메시지 입력칸을 클릭하세요.');
  const normalize = t => (t || '').replace(/\r\n/g,'\n').replace(/\u00a0/g,' ').trim();
  const isInput=editor.tagName==='TEXTAREA'||editor.tagName==='INPUT';
  const read = () => normalize(isInput ? editor.value : editor.innerText);
  const expected = normalize(req.text);
  const names = req.files || [];
  // Restrict attachment evidence to the live composer, never earlier chat messages.
  const sendSelector='button[data-testid="send-button"],button.send-button,button[aria-label="Send message"],button[aria-label="Submit"],button[aria-label="Send"],button[aria-label="전송"],button[aria-label="보내기"],button[aria-label="메시지 보내기"],button[aria-label="메시지 전송"]';
  let composer=editor.closest('form,[data-testid*="composer"],.input-area');
  if(!composer)for(let e=editor.parentElement,depth=0;e && e!==document.body && e.tagName!=='MAIN' && depth<12;e=e.parentElement,depth++){
    if(e.querySelector('[data-message-author-role],[data-testid="user-message"],[data-testid="assistant-message"]'))break;
    const hasAttach=Array.from(e.querySelectorAll('button')).some(b=>visible(b) && /^(파일.*추가|첨부|add (files|attachments)|attach (files|images))/i.test(buttonLabel(b)));
    if(e.querySelector(sendSelector) || hasAttach){composer=e;break;}
  }
  const attachmentReady=()=>{
    const state=window.__quorumUpload;
    if(!state || state.token!==req.token || state.editor!==editor || !composer)
      return answer(false,'첨부 상태가 바뀌었습니다. 각 화면을 확인하세요.');
    const nodes=[composer,...composer.querySelectorAll('*')].filter(visible);
    const busy=nodes.some(e=>e.matches('[role="progressbar"],[aria-busy="true"]') || /^(uploading|processing|업로드 중|처리 중)/i.test(e.getAttribute('aria-label')||''));
    if(busy)return answer(false,'파일 업로드 중…',{waiting:true});
    const errors=nodes.filter(e=>e.matches('[role="alert"],[data-testid*="error"]')).map(e=>e.innerText||'').join(' ');
    if(/fail|error|unsupported|exceed|too large|실패|오류|지원하지|초과/i.test(errors))return answer(false,'첨부 오류: '+errors.slice(0,120));
    const labels=nodes.flatMap(e=>[e.getAttribute('title'),e.getAttribute('aria-label'),e.getAttribute('alt'),e.childElementCount===0?e.textContent:''].filter(Boolean).map(s=>s.trim()));
    // input.files only proves selection, not successful acceptance by the site.
    if(!names.every(name=>labels.some(label=>label===name || label.startsWith(name+' ') || label.endsWith(' '+name))))
      return answer(false,'첨부 완료를 확인 중… 각 화면의 파일 표시를 확인하세요.',{waiting:true});
    return answer(true,'첨부 표시 확인됨');
  };
  if(req.action==='attachment-ready')return attachmentReady();
  if(req.action==='attachment-prepare'){
    if(!names.length || !composer)return answer(false,'첨부할 채팅 입력 영역을 찾지 못했습니다.');
    if(read() && read()!==expected)return answer(false,'기존 작성 중인 내용이 있어 첨부하지 않았습니다.');
    if(window.__quorumUpload && window.__quorumUpload.token===req.token && window.__quorumUpload.editor===editor)
      return answer(true,'이미 첨부를 요청했습니다.',{reuse:true});
    const prior=window.__quorumUpload;
    const existing=Array.from(composer.querySelectorAll('input[type="file"]')).some(e=>e.files.length>0) ||
      Array.from(composer.querySelectorAll('button')).some(e=>visible(e) && /remove.*(file|attachment|image)|delete.*(file|attachment|image)|(파일|첨부|이미지).*(삭제|제거)/i.test(e.getAttribute('aria-label')||e.getAttribute('title')||''));
    if(existing || (prior && prior.editor===editor && prior.names.some(name=>(composer.innerText||'').includes(name))))
      return answer(false,'이 채팅에 이전 첨부가 남아 있습니다. 화면에서 제거한 뒤 다시 보내세요.');
    let inputs=all('input[type="file"]').filter(e=>!e.disabled && !e.webkitdirectory && (names.length===1 || e.multiple));
    const accepts=(input,name)=>{
      const rules=(input.accept||'').toLowerCase().split(',').map(x=>x.trim()).filter(Boolean);
      if(!rules.length || rules.includes('*/*'))return true;
      const ext=name.toLowerCase().split('.').pop();
      const mime={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',bmp:'image/bmp',pdf:'application/pdf',txt:'text/plain',csv:'text/csv',json:'application/json',mp4:'video/mp4',mp3:'audio/mpeg'}[ext];
      return rules.some(rule=>rule==='.'+ext || (mime && (rule===mime || rule===mime.split('/')[0]+'/*')));
    };
    inputs=inputs.filter(e=>names.every(name=>accepts(e,name)));
    if(inputs.some(e=>composer.contains(e)))inputs=inputs.filter(e=>composer.contains(e));
    // These composers can expose several unrelated file pickers (project files,
    // photos, documents). Deliver images to the editor's paste handler instead
    // of guessing which hidden input belongs to this conversation.
    if(inputs.length!==1){
      const imagePaste=['ChatGPT','Claude'].includes(req.provider) && names.every(name=>/\.(png|jpe?g|gif|webp|bmp)$/i.test(name));
      if(imagePaste){
        window.__quorumUpload={token:req.token,names:[...names],editor};
        return answer(true,'이미지 붙여넣기 준비됨',{reuse:false,method:'paste'});
      }
      return answer(false,'파일 첨부 입력을 찾지 못했거나 여러 개입니다. 이 AI의 첨부 메뉴를 열고 재시도하세요.');
    }
    if(inputs[0].files.length)return answer(false,'파일 선택기에 기존 첨부가 있습니다. 각 화면에서 확인하세요.');
    all('input[data-quorum-upload]').forEach(e=>e.removeAttribute('data-quorum-upload'));
    inputs[0].setAttribute('data-quorum-upload',req.token);
    window.__quorumUpload={token:req.token,names:[...names],editor};
    return answer(true,'첨부 입력 준비됨',{reuse:false});
  }
  if (req.action === 'read') return answer(true,'읽기 완료',{text:read()});
  if (!expected && !names.length) return answer(false,'보낼 내용이 비어 있습니다.');
  if (req.action === 'fill') {
    const before = read();
    if (before && before !== expected) return answer(false,'기존 작성 중인 내용이 있어 덮어쓰지 않았습니다.');
    if (before === expected) return answer(true,'동일한 내용이 이미 입력되어 있습니다.');
    editor.focus();
    if (isInput) {
      Object.getOwnPropertyDescriptor(editor.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,'value').set.call(editor,req.text);
      editor.dispatchEvent(new Event('input',{bubbles:true}));
      editor.dispatchEvent(new Event('change',{bubbles:true}));
    } else {
      const range=document.createRange(); range.selectNodeContents(editor);
      const selection=window.getSelection(); selection.removeAllRanges(); selection.addRange(range);
      if (!document.execCommand('insertText',false,req.text)) return answer(false,'이 입력칸은 자동 입력을 지원하지 않습니다. 직접 붙여넣어 주세요.');
      editor.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:req.text}));
    }
    return read()===expected ? answer(true,'입력됨 · 확인 후 전송하세요') : answer(false,'입력 결과가 일치하지 않습니다. 직접 확인하세요.');
  }
  if (req.action === 'send') {
    if (read() !== expected) return answer(false,'입력 내용이 바뀌었습니다. 다시 넣거나 직접 전송하세요.');
    if(names.length){const status=attachmentReady();if(!status.ok)return status;}
    else if(composer && window.__quorumUpload && window.__quorumUpload.editor===editor){
      const prior=window.__quorumUpload;
      if(prior.names.some(name=>(composer.innerText||'').includes(name)) || Array.from(composer.querySelectorAll('input[type="file"]')).some(e=>e.files.length))
        return answer(false,'이 채팅에 이전 첨부가 남아 있습니다. 화면에서 제거하거나 직접 전송하세요.');
    }
    let candidates=[];
    for (const selector of p.send) candidates.push(...all(selector));
    candidates.push(...all('button').filter(e => /^(send|send message|submit|전송|메시지 보내기|메시지 전송|보내기|프롬프트 전송|프롬프트 보내기)$/i.test(e.getAttribute('aria-label') || e.getAttribute('title') || '')));
    candidates=[...new Set(candidates)].filter(e=>visible(e) && !e.disabled && e.getAttribute('aria-disabled')!=='true');
    const scope=editor.closest('form');
    if(scope && candidates.some(e=>scope.contains(e)))candidates=candidates.filter(e=>scope.contains(e));
    if (candidates.length !== 1) return answer(false,'전송 버튼을 확실히 식별하지 못했습니다. 각 화면에서 직접 전송하세요.');
    candidates[0].click();
    return answer(true,'전송 버튼 클릭됨 · 실제 접수 여부는 각 화면 확인');
  }
  return answer(false,'알 수 없는 요청');
})();
